.\Run-Tests.ps1 -TestName "Test 3" -Loops 10 -Spawns 25
