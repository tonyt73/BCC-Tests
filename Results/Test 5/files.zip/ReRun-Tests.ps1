.\Run-Tests.ps1 -TestName "Test 5" -Loops 20 -Spawns 49
