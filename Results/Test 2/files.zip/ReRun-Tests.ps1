.\Run-Tests.ps1 -TestName "Test 2" -Loops 25 -Spawns 25
