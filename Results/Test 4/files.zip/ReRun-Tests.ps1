.\Run-Tests.ps1 -TestName "Test 4" -Loops 10 -Spawns 50
